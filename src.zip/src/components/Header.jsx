import { Link } from 'react-router-dom';

const Header = () => {
  return (
    <header className="header">
      <div className="header-left">
        <Link to="/" className="logo">CINEMEX</Link>
        <nav className="nav-links">
          <Link to="/cartelera">Cartelera</Link>
          <Link to="/alimentos">Alimentos</Link>
          <Link to="/otros">Promociones</Link>
        </nav>
      </div>
      <div className="header-right">
         <span style={{ fontSize: '0.9rem', cursor: 'pointer' }}>Iniciar Sesión</span>
      </div>
    </header>
  );
};

export default Header;