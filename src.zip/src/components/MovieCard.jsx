import { Link } from 'react-router-dom';
import Button from './Button';

const MovieCard = ({ id, title, genre, image }) => {
  return (
    <div className="card">
      <img src={image} alt={title} className="poster-img" />
      <div className="card-content">
        <h3 className="card-title">{title}</h3>
        <p className="card-subtitle">{genre}</p>
        
        {/* El Link envuelve al botón y lo lleva a /pelicula/1, /pelicula/2, etc. */}
        <Link to={`/pelicula/${id}`} style={{ textDecoration: 'none', display: 'flex', flexDirection: 'column', marginTop: 'auto' }}>
          <Button text="Ver Detalles" />
        </Link>
      </div>
    </div>
  );
};

export default MovieCard;