import MovieCard from '../components/MovieCard';
import { moviesData } from '../moviesData'; // Importamos los datos

const Cartelera = () => {
  return (
    <div>
      <h1 className="page-title" style={{ textAlign: 'center', marginTop: '30px' }}>CARTELERA</h1>
      <div className="grid-container">
        {moviesData.map(movie => (
          <MovieCard key={movie.id} {...movie} />
        ))}
      </div>
    </div>
  );
};

export default Cartelera;