import { useParams, Link } from 'react-router-dom';
import { moviesData } from '../moviesData';
import Button from '../components/Button';

const Detalle = () => {
  const { id } = useParams(); // Obtenemos el ID de la URL
  
  // Buscamos la película que coincida con ese ID
  const movie = moviesData.find(m => m.id === parseInt(id));

  // Si alguien pone un ID que no existe en la URL:
  if (!movie) {
    return <h2 style={{ textAlign: 'center', marginTop: '50px' }}>Película no encontrada</h2>;
  }

  return (
    <div className="detalle-container">
      <div className="detalle-img-container">
        <img src={movie.image} alt={movie.title} className="detalle-img" />
      </div>
      
      <div className="detalle-info">
        <h1 className="detalle-title">{movie.title}</h1>
        <p className="detalle-genre">{movie.genre}</p>
        
        <h3 style={{ marginBottom: '10px', color: 'var(--cx-dark)' }}>Sinopsis</h3>
        <p className="detalle-synopsis">{movie.synopsis}</p>
        
        <div style={{ display: 'flex', gap: '15px', marginTop: '20px' }}>
          <Button text="Comprar Boletos" />
          <Link to="/cartelera">
            <button className="btn" style={{ backgroundColor: '#666' }}>Volver</button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Detalle;